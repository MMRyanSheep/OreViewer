package kaptainwutax.seedcrackerX.finder;

import kaptainwutax.seedcrackerX.finder.decorator.EndPillarsFinder;
import kaptainwutax.seedcrackerX.finder.decorator.ore.EmeraldOreFinder;
import kaptainwutax.seedcrackerX.finder.structure.AbstractTempleFinder;
import kaptainwutax.seedcrackerX.finder.structure.BuriedTreasureFinder;
import kaptainwutax.seedcrackerX.finder.structure.EndCityFinder;
import kaptainwutax.seedcrackerX.finder.structure.IglooFinder;
import kaptainwutax.seedcrackerX.finder.structure.MonumentFinder;
import kaptainwutax.seedcrackerX.finder.structure.OutpostFinder;
import kaptainwutax.seedcrackerX.finder.structure.TrialChambersFinder;
import kaptainwutax.seedcrackerX.util.HeightContext;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;

public class ReloadFinders {
   public Minecraft client = Minecraft.getInstance();

   public static void reloadHeight(int minY, int maxY) {
      Finder.CHUNK_POSITIONS.clear();

      for (int x = 0; x < 16; x++) {
         for (int z = 0; z < 16; z++) {
            for (int y = minY; y < maxY; y++) {
               Finder.CHUNK_POSITIONS.add(new BlockPos(x, y, z));
            }
         }
      }

      Finder.heightContext = new HeightContext(minY, maxY);
      EmeraldOreFinder.reloadSearchPositions();
      EndPillarsFinder.BedrockMarkerFinder.reloadSearchPositions();
      AbstractTempleFinder.reloadSearchPositions();
      BuriedTreasureFinder.reloadSearchPositions();
      EndCityFinder.reloadSearchPositions();
      MonumentFinder.reloadSearchPositions();
      OutpostFinder.reloadSearchPositions();
      IglooFinder.reloadSearchPositions();
      TrialChambersFinder.reloadSearchPositions();
   }

   public void reload() {
      int renderdistance = (Integer)this.client.options.renderDistance().get();
      int playerChunkX = (int)(Math.round(this.client.player.getX()) >> 4);
      int playerChunkZ = (int)(Math.round(this.client.player.getZ()) >> 4);

      for (int i = playerChunkX - renderdistance; i < playerChunkX + renderdistance; i++) {
         for (int j = playerChunkZ - renderdistance; j < playerChunkZ + renderdistance; j++) {
            FinderQueue.get().onChunkData(this.client.level, new ChunkPos(i, j));
         }
      }
   }
}
