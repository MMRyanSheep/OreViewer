package kaptainwutax.seedcrackerX.cracker.storage;

import com.seedfinding.mcbiome.source.OverworldBiomeSource;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.rand.seed.PillarSeed;
import com.seedfinding.mccore.rand.seed.StructureSeed;
import com.seedfinding.mccore.rand.seed.WorldSeed;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.structure.OldStructure;
import com.seedfinding.mcfeature.structure.PillagerOutpost;
import com.seedfinding.mcfeature.structure.RegionStructure;
import com.seedfinding.mcfeature.structure.Shipwreck;
import com.seedfinding.mcfeature.structure.UniformStructure;
import com.seedfinding.mcfeature.structure.RegionStructure.Data;
import com.seedfinding.mcseed.lcg.LCG;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import kaptainwutax.seedcrackerX.SeedCracker;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.cracker.BiomeData;
import kaptainwutax.seedcrackerX.cracker.bedrock.BedrockCollector;
import kaptainwutax.seedcrackerX.cracker.decorator.Decorator;
import kaptainwutax.seedcrackerX.util.Database;
import kaptainwutax.seedcrackerX.util.Log;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.XoroshiroRandomSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TimeMachine {
   private static final Logger logger = LoggerFactory.getLogger("timeMachine");
   public static ExecutorService SERVICE = Executors.newFixedThreadPool(5);
   private final LCG inverseLCG = LCG.JAVA.combine(-2L);
   public boolean isRunning = false;
   public boolean shouldTerminate = false;
   public List<Integer> pillarSeeds = null;
   public Set<Long> structureSeeds = new HashSet<>();
   public Set<Long> worldSeeds = new HashSet<>();
   protected DataStorage dataStorage;

   public TimeMachine(DataStorage dataStorage) {
      this.dataStorage = dataStorage;
   }

   public void poke(TimeMachine.Phase phase) {
      if (this.worldSeeds.size() != 1) {
         this.isRunning = true;

         while (phase != null && !this.shouldTerminate) {
            if (phase != TimeMachine.Phase.BIOMES && this.pokeStructureReduce()) {
               phase = TimeMachine.Phase.BIOMES;
            } else {
               if (phase == TimeMachine.Phase.STRUCTURES
                  ? !this.pokeStructures()
                  : (
                     phase == TimeMachine.Phase.LIFTING
                        ? !this.pokeStructures() && !this.pokeLifting()
                        : (phase == TimeMachine.Phase.PILLARS ? !this.pokePillars() : phase == TimeMachine.Phase.BIOMES && !this.pokeBiomes())
                  )) {
                  break;
               }

               phase = phase.nextPhase();
            }
         }

         if (this.worldSeeds.size() == 1 && !this.shouldTerminate) {
            long seed = this.worldSeeds.stream().findFirst().get();
            SeedCracker.entrypoints.forEach(entrypoint -> entrypoint.pushWorldSeed(seed));

            try {
               BedrockCollector.get().onExternalSeedFound(seed);
            } catch (Throwable var6) {
            }

            Config.get().active = false;
            Config.save();
            Log.warn("ks.finished");
            Minecraft client = Minecraft.getInstance();
            if (Config.get().databaseSubmits
               && client.getConnection().getOnlinePlayers().size() > 10
               && !client.getConnection().getConnection().isMemoryConnection()) {
               Component text = Database.joinFakeServerForAuth();
               if (text == null) {
                  Database.handleDatabaseCall(seed);
               } else {
                  Log.error(text.getString());
               }
            }
         }
      }
   }

   protected boolean pokePillars() {
      if (this.pillarSeeds == null && this.dataStorage.pillarData != null) {
         this.pillarSeeds = new ArrayList<>();
         Log.debug("====================================");
         Log.warn("tmachine.lookingForPillarSeed");

         for (int pillarSeed = 0; pillarSeed < 65536 && !this.shouldTerminate; pillarSeed++) {
            if (this.dataStorage.pillarData.test(pillarSeed)) {
               Log.printSeed("tmachine.foundPillarSeed", pillarSeed);
               this.pillarSeeds.add(pillarSeed);
            }
         }

         if (!this.pillarSeeds.isEmpty()) {
            Log.warn("tmachine.pillarSeedSearchFinished");
         } else {
            Log.error("finishedSearchNoResult");
         }

         return true;
      } else {
         return false;
      }
   }

   protected boolean pokeLifting() {
      if (this.structureSeeds.isEmpty() && !(this.dataStorage.getLiftingBits() < 40.0)) {
         List<Data<?>> dataList = new ArrayList<>();

         for (DataStorage.Entry<com.seedfinding.mcfeature.Feature.Data<?>> e : this.dataStorage.baseSeedData) {
            if (e.data.feature instanceof OldStructure || e.data.feature instanceof Shipwreck) {
               dataList.add((Data<?>)e.data);
            }
         }

         List<com.seedfinding.mcfeature.Feature.Data<?>> cache = new ArrayList<>();

         for (DataStorage.Entry<com.seedfinding.mcfeature.Feature.Data<?>> entry : this.dataStorage.baseSeedData) {
            if ((!(entry.data.feature instanceof Decorator) || entry.data.feature.getVersion().isOlderThan(MCVersion.v1_18))
               && !(entry.data.feature instanceof PillagerOutpost)) {
               cache.add(entry.data);
            }
         }

         Log.warn("tmachine.startLifting", dataList.size());
         Stream<Long> lowerBitsStream = LongStream.range(0L, 524288L)
            .boxed()
            .filter(
               lowerBits -> {
                  ChunkRand rand = new ChunkRand();

                  for (Data<?> data : dataList) {
                     rand.setRegionSeed(lowerBits, data.regionX, data.regionZ, ((RegionStructure)data.feature).getSalt(), Config.get().getVersion());
                     if (rand.nextInt(((UniformStructure)data.feature).getOffset()) % 4 != data.offsetX % 4
                        || rand.nextInt(((UniformStructure)data.feature).getOffset()) % 4 != data.offsetZ % 4) {
                        return false;
                     }
                  }

                  return true;
               }
            );
         Stream<Long> seedStream = lowerBitsStream.flatMap(lowerBits -> LongStream.range(0L, 536870912L).boxed().map(upperBits -> upperBits << 19 | lowerBits));
         Stream<Long> strutureSeedStream = seedStream.filter(seed -> {
            ChunkRand rand = new ChunkRand();

            for (com.seedfinding.mcfeature.Feature.Data<?> data : cache) {
               if (!data.testStart(seed, rand)) {
                  return false;
               }
            }

            return true;
         });
         this.structureSeeds = strutureSeedStream.parallel().collect(Collectors.toSet());
         if (!this.structureSeeds.isEmpty()) {
            Log.warn("tmachine.structureSeedSearchFinished");
         } else {
            Log.error("finishedSearchNoResult");
         }

         return !this.structureSeeds.isEmpty();
      } else {
         return false;
      }
   }

   protected boolean pokeStructures() {
      if (this.pillarSeeds != null && this.structureSeeds.isEmpty() && !(this.dataStorage.getBaseBits() < this.dataStorage.getWantedBits())) {
         List<com.seedfinding.mcfeature.Feature.Data<?>> cache = new ArrayList<>();

         for (DataStorage.Entry<com.seedfinding.mcfeature.Feature.Data<?>> entry : this.dataStorage.baseSeedData) {
            if ((!(entry.data.feature instanceof Decorator) || entry.data.feature.getVersion().isOlderThan(MCVersion.v1_18))
               && !(entry.data.feature instanceof PillagerOutpost)) {
               cache.add(entry.data);
            }
         }

         for (int pillarSeed : this.pillarSeeds) {
            Log.debug("====================================");
            Log.warn("tmachine.lookingForStructureSeeds", pillarSeed);
            AtomicInteger completion = new AtomicInteger();
            ProgressListener progressListener = new ProgressListener();

            for (int threadId = 0; threadId < 4; threadId++) {
               int fThreadId = threadId;
               SERVICE.submit(() -> {
                  ChunkRand rand = new ChunkRand();
                  long lower = fThreadId * 1073741824L;
                  long upper = (fThreadId + 1) * 1073741824L;

                  for (long partialWorldSeed = lower; partialWorldSeed < upper && !this.shouldTerminate; partialWorldSeed++) {
                     if ((partialWorldSeed & 134217727L) == 0L) {
                        progressListener.addPercent(3.125F, true);
                     }

                     long seed = this.timeMachine(partialWorldSeed, pillarSeed);
                     boolean matches = true;
                     Iterator i$ = cache.iterator();

                     while (true) {
                        if (i$.hasNext()) {
                           com.seedfinding.mcfeature.Feature.Data<?> baseSeedDatum = (com.seedfinding.mcfeature.Feature.Data<?>)i$.next();
                           if (baseSeedDatum.testStart(seed, rand)) {
                              continue;
                           }

                           matches = false;
                        }

                        if (matches) {
                           this.structureSeeds.add(seed);
                           Log.printSeed("foundStructureSeed", seed);
                        }
                        break;
                     }
                  }

                  completion.getAndIncrement();
               });
            }

            while (completion.get() != 4) {
               try {
                  Thread.sleep(50L);
               } catch (InterruptedException e) {
                  e.printStackTrace();
               }

               if (this.shouldTerminate) {
                  return false;
               }
            }

            progressListener.addPercent(0.0F, true);
         }

         if (!this.structureSeeds.isEmpty()) {
            Log.warn("tmachine.structureSeedSearchFinished");
         } else {
            Log.error("finishedSearchNoResult");
         }

         return true;
      } else {
         return false;
      }
   }

   protected boolean pokeBiomes() {
      if (!this.structureSeeds.isEmpty() && this.worldSeeds.size() != 1) {
         if (this.structureSeeds.size() > 1000) {
            return false;
         }

         Log.debug("====================================");
         this.worldSeeds.clear();
         this.dataStorage.baseSeedData.dump();
         if (Config.get().getVersion().isNewerOrEqualTo(MCVersion.v1_18) && this.dataStorage.getDecoratorBits() > 32.0) {
            Log.warn("tmachine.decoratorWorldSeedSearch");
            WorldgenRandom rand = new WorldgenRandom(new XoroshiroRandomSource(0L));

            for (long structureSeed : this.structureSeeds) {
               for (long upperBits = 0L; upperBits < 65536L && !this.shouldTerminate; upperBits++) {
                  long worldSeed = upperBits << 48 | structureSeed;
                  boolean matches = true;

                  for (DataStorage.Entry<com.seedfinding.mcfeature.Feature.Data<?>> e : this.dataStorage.baseSeedData.getBaseSet()) {
                     if (e.data.feature instanceof Decorator && !((Decorator.Data)e.data).testStart(worldSeed, rand)) {
                        matches = false;
                        break;
                     }
                  }

                  if (matches) {
                     this.worldSeeds.add(worldSeed);
                     if (this.worldSeeds.size() < 10) {
                        Log.printSeed("tmachine.foundWorldSeed", worldSeed);
                        if (this.worldSeeds.size() == 9) {
                           Log.warn("tmachine.printSeedsInConsole");
                        }
                     } else {
                        logger.info("Found world seed " + worldSeed);
                     }
                  }

                  if (this.shouldTerminate) {
                     return false;
                  }
               }
            }

            if (!this.worldSeeds.isEmpty()) {
               Log.warn("tmachine.worldSeedSearchFinished");
               return true;
            }

            Log.warn("finishedSearchNoResult");
         }

         if (this.dataStorage.hashedSeedData != null && this.dataStorage.hashedSeedData.getHashedSeed() != 0L) {
            Log.warn("tmachine.hashedSeedWorldSeedSearch");

            for (long structureSeed : this.structureSeeds) {
               WorldSeed.fromHash(structureSeed, this.dataStorage.hashedSeedData.getHashedSeed()).forEach(worldSeedx -> {
                  this.worldSeeds.add(worldSeedx);
                  Log.printSeed("tmachine.foundWorldSeed", worldSeedx);
               });
               if (this.shouldTerminate) {
                  return false;
               }
            }

            if (!this.worldSeeds.isEmpty()) {
               Log.warn("tmachine.worldSeedSearchFinished");
               return true;
            }

            this.dataStorage.hashedSeedData = null;
            Log.error("tmachine.noResultsRevertingToBiomes");
         }

         this.dataStorage.biomeSeedData.dump();
         if (this.dataStorage.notEnoughBiomeData()) {
            Log.error("tmachine.moreBiomesNeeded");
            return false;
         }

         Log.warn("tmachine.biomeWorldSeedSearch", this.dataStorage.biomeSeedData.size());
         Log.warn("tmachine.fuzzyBiomeSearch");
         MCVersion version = Config.get().getVersion();

         for (long structureSeed : this.structureSeeds) {
            for (long worldSeed : StructureSeed.toRandomWorldSeeds(structureSeed)) {
               OverworldBiomeSource source = new OverworldBiomeSource(version, worldSeed);
               boolean matches = true;

               for (DataStorage.Entry<BiomeData> e : this.dataStorage.biomeSeedData) {
                  if (!e.data.test(source)) {
                     matches = false;
                     break;
                  }
               }

               if (matches) {
                  this.worldSeeds.add(worldSeed);
                  Log.printSeed("tmachine.foundWorldSeed", worldSeed);
               }

               if (this.shouldTerminate) {
                  return false;
               }
            }
         }

         if (!this.worldSeeds.isEmpty()) {
            return true;
         }

         if (this.structureSeeds.size() > 10) {
            return false;
         }

         Log.warn("tmachine.deepBiomeSearch");

         for (long structureSeed : this.structureSeeds) {
            for (long upperBits = 0L; upperBits < 65536L && !this.shouldTerminate; upperBits++) {
               long worldSeed = upperBits << 48 | structureSeed;
               OverworldBiomeSource source = new OverworldBiomeSource(version, worldSeed);
               boolean matches = true;

               for (DataStorage.Entry<BiomeData> e : this.dataStorage.biomeSeedData) {
                  if (!e.data.test(source)) {
                     matches = false;
                     break;
                  }
               }

               if (matches) {
                  this.worldSeeds.add(worldSeed);
                  if (this.worldSeeds.size() < 10) {
                     Log.printSeed("tmachine.foundWorldSeed", worldSeed);
                     if (this.worldSeeds.size() == 9) {
                        Log.warn("tmachine.printSeedsInConsole");
                     }
                  } else {
                     logger.info("Found world seed " + worldSeed);
                  }
               }

               if (this.shouldTerminate) {
                  return false;
               }
            }
         }

         this.dispSearchEnd();
         if (!this.worldSeeds.isEmpty()) {
            return true;
         }

         Log.error("tmachine.deleteBiomeInformation");
         this.dataStorage.biomeSeedData.getBaseSet().clear();
         Log.warn("tmachine.randomSeedSearch");

         for (long structureSeed : this.structureSeeds) {
            StructureSeed.toRandomWorldSeeds(structureSeed).forEach(s -> Log.printSeed("tmachine.foundWorldSeed", s));
         }

         return true;
      } else {
         return false;
      }
   }

   protected boolean pokeStructureReduce() {
      if (this.shouldTerminate) {
         return false;
      }

      if (!this.worldSeeds.isEmpty() || this.structureSeeds.size() < 2) {
         return false;
      }

      if (Config.get().getVersion().isOlderThan(MCVersion.v1_13)) {
         return false;
      }

      Set<Long> result = new HashSet<>();
      Log.debug("====================================");
      Log.warn("tmachine.reduceSeeds", this.structureSeeds.size());
      if (this.pillarSeeds != null) {
         this.structureSeeds.forEach(seedx -> {
            if (this.pillarSeeds.contains((int)PillarSeed.fromStructureSeed(seedx))) {
               result.add(seedx);
            }
         });
      }

      if (result.size() != 1) {
         this.dataStorage.baseSeedData.dump();
         this.dataStorage.baseSeedData.getBaseSet().removeIf(dataEntry -> !dataEntry.data.feature.getVersion().equals(Config.get().getVersion()));
         List<com.seedfinding.mcfeature.Feature.Data<?>> cache = new ArrayList<>();

         for (DataStorage.Entry<com.seedfinding.mcfeature.Feature.Data<?>> entry : this.dataStorage.baseSeedData) {
            if ((!(entry.data.feature instanceof Decorator) || entry.data.feature.getVersion().isOlderThan(MCVersion.v1_18))
               && !(entry.data.feature instanceof PillagerOutpost)) {
               cache.add(entry.data);
            }
         }

         ChunkRand rand = new ChunkRand();

         for (Long seed : this.structureSeeds) {
            boolean matches = true;

            for (com.seedfinding.mcfeature.Feature.Data<?> baseSeedDatum : cache) {
               if (!baseSeedDatum.testStart(seed, rand)) {
                  matches = false;
                  break;
               }
            }

            if (matches) {
               result.add(seed);
            }
         }
      }

      if (!result.isEmpty() && this.structureSeeds.size() > result.size()) {
         if (result.size() < 10) {
            result.forEach(seedx -> Log.printSeed("foundStructureSeed", seedx));
         } else {
            Log.warn("tmachine.succeedReducing", result.size());
         }

         this.structureSeeds = result;
         return true;
      } else {
         Log.warn("tmachine.failedReducing");
         return false;
      }
   }

   private void dispSearchEnd() {
      if (!this.worldSeeds.isEmpty()) {
         Log.warn("tmachine.worldSeedSearchFinished");
      } else {
         Log.error("finishedSearchNoResult");
      }
   }

   public long timeMachine(long partialWorldSeed, int pillarSeed) {
      long currentSeed = 0L;
      currentSeed |= (partialWorldSeed & 4294901760L) << 16;
      currentSeed |= (long)pillarSeed << 16;
      currentSeed |= partialWorldSeed & 65535L;
      currentSeed = this.inverseLCG.nextSeed(currentSeed);
      return currentSeed ^ LCG.JAVA.multiplier;
   }

   public enum Phase {
      BIOMES(null),
      STRUCURE_REDUCE(BIOMES),
      STRUCTURES(BIOMES),
      LIFTING(STRUCURE_REDUCE),
      PILLARS(STRUCTURES);

      private final TimeMachine.Phase nextPhase;

      Phase(TimeMachine.Phase nextPhase) {
         this.nextPhase = nextPhase;
      }

      public TimeMachine.Phase nextPhase() {
         return this.nextPhase;
      }
   }
}
