package kaptainwutax.seedcrackerX.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import kaptainwutax.seedcrackerX.config.Config;
import kaptainwutax.seedcrackerX.util.Log;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.ChatFormatting;

public class RenderCommand extends ClientCommand {
   @Override
   public String getName() {
      return "render";
   }

   @Override
   public void build(LiteralArgumentBuilder<FabricClientCommandSource> builder) {
      builder.then(ClientCommands.literal("outlines").executes(context -> this.printRenderMode()));

      for (Config.RenderType renderType : Config.RenderType.values()) {
         builder.then(
            ClientCommands.literal("outlines").then(ClientCommands.literal(renderType.toString()).executes(context -> this.setRenderMode(renderType)))
         );
      }
   }

   private int printRenderMode() {
      sendFeedback(Log.translate("render.getRenderMode") + " [" + Config.get().render + "].", ChatFormatting.AQUA);
      return 0;
   }

   private int setRenderMode(Config.RenderType renderType) {
      Config.get().render = renderType;
      Config.save();
      sendFeedback(Log.translate("render.setRenderMode") + " [" + Config.get().render + "].", ChatFormatting.AQUA);
      return 0;
   }
}
